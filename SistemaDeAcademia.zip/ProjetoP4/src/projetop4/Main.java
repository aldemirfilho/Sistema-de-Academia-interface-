package projetop4;
import java.awt.EventQueue;
import java.util.*; 
import javax.swing.JOptionPane;
import projetop4.TelaLogin;

public class Main {
	
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        int input = -1;
        /*
        ArrayList<Cliente> clientes = new ArrayList<Cliente>();
        ArrayList<Funcionario> funcionarios = new ArrayList<Funcionario>();
        ArrayList<Equipamento> equipamentos = new ArrayList<Equipamento>();*/

        JOptionPane.showMessageDialog(null, "    Bem vindo a Academia!!\n");
        JOptionPane.showMessageDialog(null, "->Realize o Login como operador, e administre o sistema da sua Academia!");
        String senha = "1234";
        /*System.out.println("\nBem-vindo!\nDigite a operação desejada:\n"
                + " 1 - Adicionar cliente\n 2 - Adicionar funcionário\n 3 - Adicionar equipamento\n 0 - Sair\n");
        */
        EventQueue.invokeLater(new Runnable(){
            public void run(){
                TelaLogin telalogin = new TelaLogin();
                telalogin.senhaEsperada = senha;
                telalogin.setVisible(true);
            }
        });
    }
}
